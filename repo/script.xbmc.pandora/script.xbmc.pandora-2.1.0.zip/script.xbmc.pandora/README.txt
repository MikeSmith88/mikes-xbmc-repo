Pandora Radio Script for XBMC

This script is released freely without restrictions, but also without
warrenty as described in the file "COPYING.txt"

Usage:

	Place in xbmc addons directory
	Set login information in script properties (prompts on run if not set)
	Pick a station and enjoy the music :)

Credits:

 - TWC Supplemental by Nuka1195
	Used extensively as a reference for building the GUI.
	Borrowed a few images for initial testing release.

 - pianobar
	Copyright (c) 2008-2010 Lars-Dominik Braun <PromyLOPh@lavabit.com>
	http://github.com/PromyLOPh/pianobar | http://6xq.net/html/00/17.html
		Uses as early reference for parts of the pandora protocol.

 - jurmb84
	Modified existing script to work with new xbmc addon framework.

 - smorloc
	Modified script to include like/dislike/tired functionality; additional
	addon settings;layout changes

 - htpc_guy
	Skins

- VTWoods
	Replaced libpandora with the pandora implementation from pithos.
